<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Matrimony</title>
    <meta content="" name="description">
    <meta content="" name="keywords">
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <meta name="robots" content="noindex, nofollow">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <link href="{{ asset('assets/images/custom/img.png') }}" rel="icon">
    <link href="{{ asset('assets/images/custom/icon.png') }}" rel="apple-touch-icon">
    <link href="https://fonts.googleapis.com" rel="preconnect">
    <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Inter:wght@100;200;300;400;500;600;700;800;900&family=Amatic+SC:wght@400;700&display=swap" rel="stylesheet">
    <link href="{{ asset('/css/custom/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('/css/custom/bootstrap-icons.css') }}" rel="stylesheet">
    <link href="{{ asset('/css/custom/aos.css') }}" rel="stylesheet">
    <link href="{{ asset('/css/custom/glightbox.min.css') }}" rel="stylesheet">
    <link href="{{ asset('/css/custom/swiper-bundle.min.css') }}" rel="stylesheet">
    <link href="{{ asset('/css/custom/virtual-select.min.css') }}" rel="stylesheet">
    <link href="{{ asset('/css/custom/custom.css') }}" rel="stylesheet">
    <link href="{{ asset('/css/custom/main.css') }}" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.css" rel="stylesheet">
    <script src="{{ asset('/js/jquery-3.7.1.min.js') }}"></script>
    <script src="{{ asset('/js/custom/virtual-select.min.js') }}"></script>
    
  </head>
